import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

import tensorflow as tf
import tensorflow_addons as tfa
import pickle
from tensorflow import keras
import numpy as np
from transformers import ElectraTokenizer,TFElectraModel,TFBertModel,BertTokenizer


class NerMetric(keras.metrics.Metric):
    def __init__(self,name='ner_category_ratio',**kwargs):
        super(NerMetric,self).__init__(name=name,**kwargs)
        self.correctA=self.add_weight(name='nc',initializer='zeros',dtype=tf.float32)
        self.correctR = self.add_weight(name='nc', initializer='zeros', dtype=tf.float32)
        self.sumA=self.add_weight(name='nsa',initializer='zeros',dtype=tf.float32)
        self.sumR=self.add_weight(name='nsr',initializer='zeros',dtype=tf.float32)

    def update_state(self,y_true,y_pred,sample_weight=None):
        y_pred=tf.boolean_mask(y_pred,y_true!=-100)
        y_true=tf.boolean_mask(y_true,y_true!=-100)
        self.sumA.assign_add(tf.reduce_sum(tf.cast(y_pred!=0,tf.float32)))
        self.sumR.assign_add(tf.reduce_sum(tf.cast(y_true!=0,tf.float32)))
        yp=tf.boolean_mask(y_pred,y_pred!=0)
        yt=tf.boolean_mask(y_true,y_pred!=0)
        self.correctA.assign_add(tf.reduce_sum(tf.cast(yp==yt,tf.float32)))
        yp=tf.boolean_mask(y_pred,y_true!=0)
        yt=tf.boolean_mask(y_true,y_true!=0)
        self.correctR.assign_add(tf.reduce_sum(tf.cast(yp==yt,tf.float32)))

    def result(self):
        # if tf.equal(self.correctA,0.) or tf.equal(self.correctR,0.):
        #     return tf.cast(self.correctA,tf.float32)
        # else:
            return  2*self.correctA*self.correctR/(self.sumA*self.correctR+self.sumR*self.correctA+1e-9)

    def reset_states(self):
        self.sumA.assign(0.0)
        self.sumR.assign(0.0)
        self.correctA.assign(0.0)
        self.correctR.assign(0.0)

class BertNerModel(keras.Model):
    def __init__(self,pretrain_path,num_tags,lstm_hidden_dim):
        super(BertNerModel,self).__init__()
        self.bert=TFBertModel.from_pretrained(pretrain_path)
        self.bilstm=keras.layers.Bidirectional(keras.layers.LSTM(lstm_hidden_dim,\
                        return_sequences=True))
        self.dense=keras.layers.Dense(num_tags)
        self.dropout = keras.layers.Dropout(0.3)
        initializer = tf.keras.initializers.GlorotUniform()
        self.transparams = tf.Variable(
            initializer([num_tags, num_tags]), "transitions"
        )

    @staticmethod
    @tf.function
    def labelprocess(data):
        labels, seqlen = data[:-1], data[-1]
        padtensor = tf.zeros(shape=labels.shape[0] - seqlen, dtype=tf.int32)
        return tf.concat([labels[:seqlen], padtensor], axis=-1)

    def call(self,data,training=False):
        inputs=data[0];labels=data[1]
        outputs=self.bert(inputs,return_dict=True,training=training)
        outputs=self.bilstm(outputs.last_hidden_state)
        outputs=self.dense(outputs)
        outputs=self.dropout(outputs,training=training)
        seqlen = tf.map_fn(tf.reduce_sum, inputs['attention_mask'])
        if training:
            labels=tf.map_fn(BertNerModel.labelprocess,tf.concat([labels,tf.expand_dims(seqlen,axis=-1)],axis=-1))
            crfoutputs,self.transparams=tfa.text.crf_log_likelihood(outputs,labels,seqlen,self.transparams)
            pre, _ = tfa.text.crf_decode(outputs, self.transparams, seqlen)
            outputs=-tf.reduce_mean(crfoutputs)
            return outputs,pre
        else:
            pre,_=tfa.text.crf_decode(outputs,self.transparams,seqlen)
            pre=pre*inputs['attention_mask']
            return pre

    def train_step(self, data):
        inputs,labels=data
        with tf.GradientTape() as tape:
            loss,pre=self(data,training=True)
        gradients=tape.gradient(loss,self.trainable_variables)
        self.optimizer.apply_gradients(zip(gradients,self.trainable_variables))
        self.compiled_metrics.update_state(labels,pre)
        return_dict={'loss':loss}
        return_dict.update({m.name:m.result() for m in self.metrics})
        return return_dict

    def test_step(self, data):
        inputs,labels=data
        pre=self(data,training=False)
        self.compiled_metrics.update_state(labels,pre)
        return {m.name:m.result() for m in self.metrics}

def load_data():
    train_data_inputs=pickle.load(open('data/train_data_inputs.pickle','rb'))
    train_labels=pickle.load(open('data/train_labels.pickle','rb'))
    dev_data_inputs = pickle.load(open('data/dev_data_inputs.pickle', 'rb'))
    dev_labels = pickle.load(open('data/dev_labels.pickle', 'rb'))
    return train_data_inputs, train_labels, dev_data_inputs, dev_labels

if __name__=='__main__':
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    train_data_inputs, train_labels, dev_data_inputs, dev_labels=load_data()
    train_dataset = tf.data.Dataset.from_tensor_slices((dict(train_data_inputs), np.array(train_labels))).shuffle(300).batch(
        12)
    dev_dataset = tf.data.Dataset.from_tensor_slices((dict(dev_data_inputs), np.array(dev_labels))).batch(12)

    model = BertNerModel('bert-base-uncased', 3, 768)
    model.compile(optimizer=keras.optimizers.Adam(0.0001), metrics=[NerMetric()])
    callbacks = [
        keras.callbacks.ModelCheckpoint(
            os.path.join('model_save', 'ckpt_loss_{val_ner_category_ratio:.4f}'), \
            save_weights_only=True, save_freq='epoch'),
        # keras.callbacks.TensorBoard('data\save_notype\log', histogram_freq=1, write_graph=True, update_freq=100)
    ]

    model.fit(train_dataset, shuffle=True, epochs=4, validation_data=dev_dataset, validation_freq=1, \
              callbacks=callbacks)